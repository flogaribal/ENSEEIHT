function [r]=power_method_dense(A,eps)
% Algorithme de la puissance iteree dans le cas "dense"
% A est la matrice dont on cherche le couple propre (r,lambda) associe a la plus
% grande valeur propre en module.
% eps est la precision souhaitee (critere d'arret).

% Initialisation
n=length(A(:,1));
r=ones(n,1)./n;


end