function [r]=power_method_sparse(Q,v,alpha,eps)
% Algorithme de la puissance iteree dans le cas "creux"
% Q est la matrice representative du graphe d'Internet.
% v est le vecteur de personalisation.
% alpha est le parametre de poids.
% eps est la precision souhaitee (critere d'arret).
% r est le vecteur propre assoicee a la valeur propre 1.

% Initialisation
n=length(Q(:,1));
r=ones(n,1)./n;

end