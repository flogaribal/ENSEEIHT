function [Q]=matrix_representation(A,n)
% Representation sous forme de matrice du graphe Internet
% A contient les arcs du graphe oriente.
% n represente le nombre de sommets.
% Q est la matrice du graphe Internet.

% Initialisation
Q=zeros(n);

end