open Bdd_base;;
open Pixel;;

(* ************************************************************************* *)
(* FONCTIONS AVANCEES SUR LES BDD                                            *)
(* ************************************************************************* *)

(* conjonction : bdd -> bdd -> bdd;;					     *)
(* La fonction qui calcule la conjonction de deux BDD.                       *)
(* Paramètres:                                                               *)
(* - deux BDD quelconques.                                                   *)
(* Résultat:                                                                 *)
(* - le bdd représentant la conjonction.                                     *)
let rec conjonction bdd1 bdd2 = 
	
	match bdd1, bdd2 with
	|Bot, _ -> bot   (* Si l'un des deux bdd est égal à Bot alors la conjonction *)
	|_, Bot -> bot   (* des deux vaut Bot 					     *)
	|Top, _ -> bdd2  (* Si l'un des deux bdd est égal à Top alors la conjonction *)
	|_,Top -> bdd1   (* des deux dépend de l'autre membre *)

	|node (f0,pix,f1), node (g0,pix1,g1) -> (* Si les pixels des deux arbres sont égaux *)
						if pix = pix1 then  
						  node (conjonction f0 g0,pix,conjonction f1 g1)
		  			        else
					    	  node (conjonction f0 (node (bdd2,pix,bdd2), pix, conjonction f1 (node (bdd2,pix,bdd2))));;	
							  
						 		     

(* substitution : (Pixel.t * Pixel.couleur) list -> bdd -> bdd;;	     *)
(* La fonction qui calcule la substitution de variables par Top ou Bot       *)
(* dans un BDD. Permet de prendre en compte l'effet d'un pixel découvert     *)
(* dans les configurations possibles.                                        *)
(* Paramètres:                                                               *)
(* - une liste de paires (pixel, couleur) représentant les variables         *)
(*   à substituer. La couleur permet de savoir par quoi il faut substituer.  *)
(* - un bdd représentant un ensemble de configurations de pixels.            *)
(* Résultat:                                                                 *)
(* - le bdd représentant la substitution des variables par Top               *)
(*   si la couleur associée est Noir, ou par Bot si la couleur est Blanc.    *)
let rec substitution listPaire bdd =
	(* Parcours de la liste de paire *) 
	match listPaire with
	|[] -> bdd	(* Si liste vide on renvoi le bdd modifié *)
	|(pix,couleur)::q -> (* Fonction auxiliaire qui permet de parcourir le bdd pour trouver le pixel recherché  *)
			     let rec aux bdd (pix,coul) = 
					match bdd with
					|top -> top
					|bot -> bot
					|node (f0,(pix1,c),f1) -> (* Si pixel trouvé *)
								 if pix = pix1 then
								     if coul = Blanc then  (* Si couleur blanc -> on renvoit le chemin direct au 
											      sous arbre gauche  *)
								  	    f0
								     else		   (* Si couleur noir -> on renvoit le chemin au sous arbre droit *)
									    f1	
							      	 else
								 (* Si pixel non trouvé -> application aux deux fils*)
								     (*   SOUS NOEUD BLANC        PIX      SOUS NOEUD NOIR  *)
								      node (aux f0 (pix,coul),(pix1,c) ,aux f1 (pix,coul))
			     in substitution q (aux bdd (pix,couleur));;
			

(* depuis_indication : int list -> Pixel.t list -> bdd;;		     *)
(* La fonction qui calcule un bdd représentant les combinaisons de pixels    *)
(* noirs, tirés dans un ensemble, à partir d'une indication.                 *)
(* Paramètres:                                                               *)
(* - une liste d'entiers [k_1;...;k_n], éventuellement vide, avec k_i > 0,   *)
(*   représentant les nombres de pixels noirs consécutifs à choisir.         *)
(* - une liste l de pixels, triée par ordre croissant, dans laquelle         *)
(*   on choisit les pixels noirs.                                            *)
(* Résultat:                                                                 *)
(* - le bdd représentant toutes les combinaisons possibles de pixels         *)
(*   de couleur noire dans l.                                                *)
let depuis_indication listInd listPixel = 

	match listInd,listPixel with
	|[],[] -> top
	|[],t::q -> Node(depuis_indication [] q,t,bot)
	|curInd::qInd, curPix::qPix ->




	
	let sumListInd = List.fold_right (fun t qt -> t+qt) listInt 0 in
		let pixMin = sumListInd + (List.len listInt)-1 in 
				
			let rec aux pixRestant minPix teteInd =  
				match listInd, listPixel with 
				|[],[] -> Top
				|[],t::q -> Node(aux pixRestant minPix 0,t,bot)
				|t::q,[] -> failwith("ERREUR")
				|t::q,t::q ->  

						aux pixRestant minPix teteInd


			in match listPixel with 
			   |[] -> aux listPixel 0 0 
			   |t::q -> aux listPixel pixMin t;;





(* ************************************************************************* *)
(* TYPES + FONCTIONS GENERALES SUR LES CONFIGURATIONS                        *)
(* ************************************************************************* *)


(* Le type abstrait dont les valeurs représentent un ensemble                *)
(* de configurations du picross.                                             *)
(* Le type des configurations doit contenir:                                 *)
(* un bdd décrivant les couleurs possibles des pixels du dessin              *)
(* + toute autre information jugée nécessaire...                             *)
type configurations = bdd*(Pixel.t*Pixel.couleur) list;;

(* indication : Pixel.couleur list -> int list;; 			     *)
(* Fonction qui calcule une indication de ligne/colonne en fonction          *)
(* de la liste de (couleurs de) pixels correspondante.                       *)
(* Paramètre:                                                                *)
(* - une ligne ou colonne de pixels sur laquelle calculer l'indication       *)
(* Résultat:                                                                 *)
(* - une indication, liste éventuellement vide d'entiers > 0                 *)
let indication liste =
	(* Parcours de la liste de couleur pixels *)
	(* La variable acc permet de compter le nombre de noir consécutifs *)
	let rec aux acc coulList = 
		match coulListe with 
		|[] -> [] 
		|Noir::q -> aux (acc+1) q
		|Blanc::q -> if acc <> 0 then
				acc::(aux 0 q)
		             else 
				aux 0 q
  	in List.rev(aux 0 liste);;


(* selection : Pixel.t * Pixel.couleur -> configurations -> configurations;; *)
(* Fonction qui force la couleur d'un pixel dans les configurations,         *)
(* réduisant leur nombre. Ce pixel ne sera plus ambigu (voir ambiguite).     *)
(* Paramètre:                                                                *)
(* - un paire (pixel, couleur)                                               *)
(* Résultat:                                                                 *)
(* - les configurations restantes où le pixel choisi a la bonne couleur      *)
let selection (pix,couleur) (bdd,pixList) = 
	((substitution [(pix,couleur)] bdd),(pix,couleur)::pixList);;

	

(* initialisation : (int list * Pixel.t list) list -> configurations;; 	     *)
(* La fonction qui calcule les configurations initiales possibles            *)
(* en fonction des indications de chaque ligne/colonne.                      *)
(* Paramètre:                                                                *)
(* - une liste de paires (indication, ligne/colonne de pixels)               *)
(* Résultat:                                                                 *)
(* - les configurations initiales possibles.                                 *)
let initialisation liste =
	((List.fold_right (fun (intList,pixList) qt -> (conjonction (depuis_indication intList pixList) qt)) liste top) ,[]);; 	

(* singleton : configurations -> bool;;					     *)
(* Fonction qui teste si un ensemble de configurations est réduit à un seul  *)
(* élément. Teste la non-ambiguïté dans les configurations possibles, i.e.   *)
(* tous les pixels ont une couleur unique dans toutes les configurations.    *)
(* Paramètres:                                                               *)
(* - un ensemble de configurations possibles                                 *)
(* Résultat:                                                                 *)
(* - le booléen indiquant s'il y a une seule configuration possible, ou non  *)
let singleton (bdd, pixList) = 
	let rec aux bdd = 
		match bdd with
		|Top -> 1
		|Bot -> 0
		|Node(f0,pix,f1) -> (aux f0) + (aux f1)

	in (aux bdd) = 1 ;;


(* ambiguite : configurations -> Pixel.t;;				     *)
(* Fonction qui calcule une ambiguïté dans les configurations possibles,     *)
(* i.e. renvoie un pixel qui n'a pas de polarité, i.e. pas de couleur unique *)
(* dans toutes les configurations.                                           *)
(* Paramètres:                                                               *)
(* - un ensemble de configurations possibles ambiguës                        *)
(* Résultat:                                                                 *)
(* - un pixel ambigu                                                         *)
(* Erreur:                                                                   *)
(* - exception levée s'il n'y a pas de pixel ambigu, i.e. l'ensemble         *)
(*   des configurations est réduit à un élément                              *)
let ambiguite (bdd,pixList) =

	let rec aux bdd =
		match bdd with
		|Top -> top
		|Bot -> bot
		|Node(f0,pix,f1) -> let bGauch, bDroit = aux f0, aux f1 in
					match bGauch,bDroit with
					|Bot,Bot -> bot
					|Bot,Top -> top
					|Top,Bot -> top
					|Top,Top -> Node(Top,pix,Top)
					|_,Node(g0,p,g1) -> Node(g0,p,g1)
					|Node(g0,p,g1),_ -> Node(g0,p,g1)
					

	in match aux bdd with
 	   |Top -> failwith("Merde...")
	   |Bot -> failwith("Merde...")
 	   |Node(f0,pix,f1) -> pixi;;
(*

	let rec aux bdd =
		match bdd with
		|Top -> (true,(-1,-1))
		|Bot -> (false,(-1,-1))
		|Node(f0,pix,f1) -> let (bGauch,p1), (bDroit,p2) = aux f0, aux f1 in
					if bGauch = bDroit and bGauch = true then
						(true,pix)
					else 
						if bGauch = true then
							(true,p1)
						else if bDroit = true then
							(true,p2)
	
	in match aux bdd with 
	   |(true,coord) -> if coord = (-1,-1) then
				failwith("Merde...")
			    else
				coord
	   |(false,_)-> failwith("ERREUR") ;;


*)
