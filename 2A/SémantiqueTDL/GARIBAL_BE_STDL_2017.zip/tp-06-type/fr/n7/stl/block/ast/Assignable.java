package fr.n7.stl.block.ast;

public interface Assignable extends Expression {

}
