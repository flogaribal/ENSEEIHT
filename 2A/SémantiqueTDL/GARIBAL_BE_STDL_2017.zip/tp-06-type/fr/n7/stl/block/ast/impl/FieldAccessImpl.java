/**
 * 
 */
package fr.n7.stl.block.ast.impl;

import fr.n7.stl.block.ast.Expression;
import fr.n7.stl.block.ast.FieldDeclaration;
import fr.n7.stl.block.ast.Type;
import fr.n7.stl.block.ast.BlockFactory;
import fr.n7.stl.block.ast.impl.BlockFactoryImpl;
import fr.n7.stl.tam.ast.Fragment;
import fr.n7.stl.block.ast.AtomicType;
import fr.n7.stl.tam.ast.TAMFactory;

/**
 * Implementation of the Abstract Syntax Tree node for accessing a field in a record.
 * @author Marc Pantel
 *
 */
public class FieldAccessImpl implements Expression {

	// CHANGED FROM PRIVATE TO PROTECTED
	protected Expression record;
	private String name;
	private FieldDeclaration field;

	public FieldAccessImpl(Expression _record, String _name) {
		this.record = _record;
		this.name = _name;
	}

	public FieldAccessImpl(Expression _record, FieldDeclaration _field) {
		this.record = _record;
		this.field = _field;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return this.record + "." + this.name;
	}

	/* (non-Javadoc)
	 * @see fr.n7.stl.block.ast.Expression#getType()
	 */
	@Override
	public Type getType() {
		Type recordType = record.getType();

		if (recordType instanceof RecordTypeImpl) {
			if (field == null) {
				BlockFactory factory = new BlockFactoryImpl();
				field = factory.createFieldDeclaration(name,(((RecordTypeImpl)recordType).get(name).get().getType()));
			}
			return field.getType();
		} else {
			System.err.println(record.toString() + " ERREUR ENREGISTREMENT");
			return AtomicType.ErrorType;
		}
	}

	/* (non-Javadoc)
	 * @see fr.n7.stl.block.ast.Expression#getCode(fr.n7.stl.tam.ast.TAMFactory)
	 */
	@Override
	public Fragment getCode(TAMFactory _factory) {
		Fragment fragment = _factory.createFragment();

		fragment.append(this.record.getCode(_factory));
//		fragment.add(_factory.create);

		return fragment;
	}

}
