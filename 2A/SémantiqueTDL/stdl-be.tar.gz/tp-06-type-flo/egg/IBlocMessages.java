package egg;
public interface IBlocMessages {

  public static final int id_Bloc_expected_token = 3080192;
  public static final int id_BLOC_undefined_ident = 3080193;
  public static final int id_B_02 = 3080194;
  public static final int id_B_01 = 3080195;
  public static final int id_B_00 = 3080196;
  public static final int id_Bloc_expected_eof = 3080197;
  public static final int id_BLOC_already_defined = 3080198;
  public static final int id_BLOC_not_a_type = 3080199;
  public static final int id_Bloc_unexpected_token = 3080200;
  }
