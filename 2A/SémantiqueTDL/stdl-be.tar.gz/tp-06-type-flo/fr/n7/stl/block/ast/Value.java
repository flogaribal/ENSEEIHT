/**
 * 
 */
package fr.n7.stl.block.ast;

/**
 * @author Marc Pantel
 *
 */
public interface Value extends Expression {

}
